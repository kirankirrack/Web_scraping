import requests
import pandas 
from bs4 import BeautifulSoup

response=requests.get("https://www.flipkart.com/mobile-phones-store?fm=neo%2Fmerchandising&iid=M_ecb4c8a4-ae54-4ed0-b847-708193721cc9_1_372UD5BXDFYS_MC.ZRQ4DKH28K8J&otracker=hp_rich_navigation_2_1.navigationCard.RICH_NAVIGATION_Mobiles_ZRQ4DKH28K8J&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_2_L0_view-all&cid=ZRQ4DKH28K8J")
print(response)

soup=BeautifulSoup(response.content,("html.parser"))
# print(soup)

names=soup.find_all("div",class_="_4rR01T")
# print(names)
name=[]
for i in names[0:20]:
    d=i.get_text()
name.append(d)
# print(name)
 



